# DRESS_RENTAL_STORE-FS-Mini-Project-
It is a simple File Structure project created using Python(Tkinter module) and file structure concepts like Hashing and Primary Indexing at the back-end.
STEPS TO RUN:-
1.install tkinter module
2.Install Python compiler
3.run:-python GUI.py

